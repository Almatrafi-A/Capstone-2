

import XCTest
@testable import FlickrWithSeachApp

class FlickrWithSeachAppTests: XCTestCase {

    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
            guard let url = URL(string: "https://api.flickr.com/services/rest?method=flickr.photos.search&api_key=1fefc897e5896c12fe577590edb94031&lat=32.34567&lon=64.45667&radius=3&format=json&nojsoncallback=1") else {
                print("Url Error")
                return
            }
            var photos = [Photo]()
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                
                guard error == nil else {
                    
                    print(error?.localizedDescription as Any)
                    return
                    
                }
                guard let response = response as? HTTPURLResponse else {
                    
                    print("Invalid Response!!")
                    return
                }
                
                guard response.statusCode >= 200 && response.statusCode < 300 else {
                    
                    print("Status Code Should Be 2xx, but the code is \(response.statusCode)")
                    
                    return
                }
                
                // 3. Step Three
                guard let model = try? JSONDecoder().decode(PhotoModel.self, from: data!) else {
                    print("faild to decode json data")
                    return
                }
               
                 photos = model.photos.photo
               
                print("Data Filled successfully")
                
            }
            
            
                task.resume()
           
        }
    }

}
