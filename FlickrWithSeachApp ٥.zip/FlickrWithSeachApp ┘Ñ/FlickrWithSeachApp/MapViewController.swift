
import UIKit
import CoreLocation
import MapKit

class MapViewController: UIViewController, UIViewControllerTransitioningDelegate{
   
    @IBOutlet var longPress: UILongPressGestureRecognizer!
    @IBOutlet weak var mapView: MKMapView!
    var locationManager = CLLocationManager()
    var currentLocation: CLLocation?
    var preciseLocationZoomLevel: Float = 15.0
    var approximateLocationZoomLevel: Float = 15.0
    override func viewDidLoad() {
        super.viewDidLoad()
       
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        let center = CLLocationCoordinate2DMake(24.774265, 46.738586)
        let regin = CLCircularRegion(center:  center, radius: 50, identifier:"twaiq")
        locationManager.startMonitoring(for: regin)
        mapView.centerCoordinate = center
        mapView.addGestureRecognizer(longPress)
        
        
    }
  
    @IBAction func gestureTapped(_ sender: UILongPressGestureRecognizer) {
        
        let touchPoint = sender.location(in: self.mapView)
        let coordinate:CLLocationCoordinate2D = mapView.convert(touchPoint, toCoordinateFrom: self.mapView)
        guard let next = storyboard?.instantiateViewController(withIdentifier: "photoView") as? ViewController else {return}
        
        next.latitude = coordinate.latitude
        next.longitude = coordinate.longitude
        next.modalPresentationStyle = .custom
        next.transitioningDelegate = self
        self.present(next, animated: false, completion: nil)
    }
    
   
 
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
            return HalfSizePresentationController(presentedViewController: presented, presenting: presentingViewController)
        }
   

}

extension MapViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print ("enter")
        
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print("exit")
    }
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let lastlocation = locations.last{
            let longitude = lastlocation.coordinate.longitude
            let latiude = lastlocation.coordinate.latitude
            print("longitude:\(longitude)")
            print(" latiude: \(latiude)")
            mapView.centerCoordinate = lastlocation.coordinate
           
            
        }
    }
    }
class HalfSizePresentationController: UIPresentationController {
    override var frameOfPresentedViewInContainerView: CGRect {
        guard let bounds = containerView?.bounds else { return .zero }
        return CGRect(x: 0, y: bounds.height / 2, width: bounds.width, height: bounds.height / 2)
    }
}
