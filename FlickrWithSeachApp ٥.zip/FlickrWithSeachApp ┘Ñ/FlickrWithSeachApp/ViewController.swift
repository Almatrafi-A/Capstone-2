

import UIKit

class ViewController: UIViewController {

    var photosList = [Photo]()
    var latitude : Double = 24.774265
     var longitude : Double = 46.738586
    @IBOutlet weak var collectionView: UICollectionView!
    var indeicator : UIActivityIndicatorView?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.indeicator =  UIActivityIndicatorView.init(frame: CGRect(x: (self.view.frame.width / 2)-100, y:  50, width: 200, height: 200))
        indeicator!.transform = CGAffineTransform.init(scaleX: 2, y: 2)
        indeicator?.color = UIColor.systemBlue
        self.view.addSubview(indeicator!)
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "CollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "CollectionViewCell")
        self.indeicator!.startAnimating()
        
        DispatchQueue.background(delay: 10.0 ,background: {
            // do something in background
            self.getPhoto(lat: self.latitude , Long: self.longitude )
            
        }, completion:{
            self.indeicator!.isHidden = true
            self.collectionView.reloadData()
        })
       
        
    }

    @IBAction func dissmissBtn(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func getPhoto(lat : Double , Long : Double )
    {
                   
        guard let url = URL(string: "https://api.flickr.com/services/rest?method=flickr.photos.search&api_key=1fefc897e5896c12fe577590edb94031&lat=\(lat)&lon=\(Long)&radius=3&format=json&nojsoncallback=1") else {
            print("Url Error")
            return
        }
        var photos = [Photo]()
       
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            
            guard error == nil else {
                
                print(error?.localizedDescription as Any)
                return
                
            }
            guard let response = response as? HTTPURLResponse else {
                
                print("Invalid Response!!")
                return
            }
            
            guard response.statusCode >= 200 && response.statusCode < 300 else {
                
                print("Status Code Should Be 2xx, but the code is \(response.statusCode)")
                
                return
            }
            
            // 3. Step Three
            guard let model = try? JSONDecoder().decode(PhotoModel.self, from: data!) else {
                print("faild to decode json data")
                return
            }
           
             photos = model.photos.photo
            self.photosList = photos
            print("Data Filled successfully")
            
        }
        
        
            task.resume()
       
      
    }
   
}

extension DispatchQueue {

    static func background(delay: Double = 0.0, background: (()->Void)? = nil, completion: (() -> Void)? = nil) {
        DispatchQueue.global(qos: .background).async {
            background?()
            if let completion = completion {
                DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: {
                    completion()
                })
            }
        }
    }

}
extension ViewController : UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return self.photosList.count
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        3
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CollectionViewCell", for: indexPath) as! CollectionViewCell
        
        let photoString = "https://live.staticflickr.com/\(photosList[indexPath.item].server)/\(photosList[indexPath.item].id)_\(photosList[indexPath.item].secret).jpg"
        
        guard let photoUrl = URL(string: photoString) else {
            
            print("Url Crash")
            return UICollectionViewCell()
        }
        
        guard let data1 = try? Data(contentsOf: photoUrl) else {
            
            print("Data Crash")
            return UICollectionViewCell()
        }
        
        cell.imageView.image = UIImage(data: data1)

        
        return cell
    }
    
    
}

